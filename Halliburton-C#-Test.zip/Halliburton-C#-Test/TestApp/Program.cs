﻿using Nancy.Hosting.Self;
using Nancy;
using System;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;
using System.Collections;
using System.IO;
using System.Collections.Generic;

namespace TestApp
{
    class Program
    {
        static void Main(string[] args)
        {
            HostConfiguration hostConfiguration = new HostConfiguration();
            hostConfiguration.UrlReservations.CreateAutomatically = true;
            var uri = "http://localhost:12345/";
            using (var host = new NancyHost(hostConfiguration, new Uri(uri)))
            {
                host.Start();
                new Module();
                Console.WriteLine("Nancy Server listening on " + uri);
                Console.ReadKey();
                host.Stop();
            }

            Console.WriteLine("Hello World!");
        }
    }
    public class Module : NancyModule
    {
        int inputNum = 0;
        public override void Get(string path, Func<dynamic, object> action, Func<NancyContext, bool> condition = null, string name = null)
        {
            var jsonText = File.ReadAllText("Data.json");
            var sponsors = JsonConvert.DeserializeObject<JSONObj>(jsonText);
            base.Get("/", parameters => { return sponsors.Status; });
        }

        public override void Post(string path, Func<dynamic, object> action, Func<NancyContext, bool> condition = null, string name = null)
        {
            var jsonText = File.ReadAllText("Data.json");
            var sponsors = JsonConvert.DeserializeObject<JSONObj>(jsonText);
            int inputNum = this.inputNum + sponsors.Result;
            base.Post("/", parameters => { return inputNum; });
        }
    }
    public class JSONObj
    {
        public string Status { get; set; }
        public int Result { get; set; }
    }
}
